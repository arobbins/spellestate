<?php
/**
 * Table rate Shipping Uninstall
 */
if ( ! defined('WP_UNINSTALL_PLUGIN') ) exit();